#!/bin/bash

SCRIPT_DIR="/home/kai/桌面/claudio-radio"
PID_FILE="/tmp/claudio-radio.pids"

# 停止已有进程
"$SCRIPT_DIR/stop.sh" 2>/dev/null
sleep 1

echo "🎵 启动 Claudio·Kai AI 电台..."

# 1. netease-api (端口 3001)
echo "🚀 启动 netease-api (端口 3001)..."
cd "$SCRIPT_DIR/netease-api" && node app.js > /tmp/claudio-netease.log 2>&1 &
NETEASE_PID=$!

# 2. qq-music-api (端口 3200) - TypeScript 直接运行
echo "🚀 启动 qq-music-api (端口 3200)..."
cd "$SCRIPT_DIR/qq-music-api" && npx tsx app.ts > /tmp/claudio-qq.log 2>&1 &
QQ_PID=$!

# 3. Claudio·Kai server (端口 3000)
echo "🚀 启动 Claudio·Kai 主服务 (端口 3000)..."
cd "$SCRIPT_DIR/server" && node index.js > /tmp/claudio-server.log 2>&1 &
SERVER_PID=$!

sleep 3

echo ""
echo "✅ 所有服务已启动！"
echo "   PID: netease=$NETEASE_PID, qq=$QQ_PID, server=$SERVER_PID"
echo ""
echo "📝 日志查看："
echo "   tail -f /tmp/claudio-netease.log  (网易云)"
echo "   tail -f /tmp/claudio-qq.log       (QQ音乐)"
echo "   tail -f /tmp/claudio-server.log  (主服务)"
echo ""
echo "🌐 浏览器打开: http://localhost:3000"
echo ""
echo "🛑 停止: $SCRIPT_DIR/stop.sh"

# 保存 PIDs
echo "$NETEASE_PID $QQ_PID $SERVER_PID" > "$PID_FILE"

# 检查服务状态
sleep 2
curl -s http://localhost:3001 -o /dev/null -w "   netease-api: %{http_code}\n" || echo "   netease-api: FAIL"
curl -s http://localhost:3200 -o /dev/null -w "   qq-music-api: %{http_code}\n" || echo "   qq-music-api: FAIL"
curl -s http://localhost:3000 -o /dev/null -w "   server: %{http_code}\n" || echo "   server: FAIL"

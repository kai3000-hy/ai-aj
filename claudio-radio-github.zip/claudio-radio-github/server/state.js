'use strict';

const fs = require('fs');
const path = require('path');

const STATE_FILE = path.join(__dirname, 'state.json');

let state = {
  mood: 'neutral',
  today_plan: '',
  current_track: null,
  messages: [],
  tracks: [],
  queue: [],
  currentIndex: -1,
  playing: false,
};

function loadState() {
  try {
    if (fs.existsSync(STATE_FILE)) {
      const data = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
      state = { ...state, ...data };
    }
  } catch (e) {
    console.warn('State load error:', e.message);
  }
}

function saveState() {
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
}

function initDb() {
  loadState();
  console.log('State loaded from', STATE_FILE);
}

function getState() {
  return {
    mood: state.mood,
    today_plan: state.today_plan,
    current_track: state.current_track,
    recentTracks: state.tracks.slice(-20),
    queue: state.queue,
    currentIndex: state.currentIndex,
    playing: state.playing,
  };
}

function setState(key, value) {
  state[key] = value;
  saveState();
}

function addMessage(role, content) {
  state.messages.push({ role, content, ts: Date.now() });
  if (state.messages.length > 200) state.messages = state.messages.slice(-200);
  saveState();
}

function getHistory(limit = 50) {
  return state.messages.slice(-limit);
}

function clearHistory() {
  state.messages = [];
  saveState();
}

function addTrack(track) {
  state.tracks.push({ ...track, played_at: Math.floor(Date.now() / 1000) });
  if (state.tracks.length > 500) state.tracks = state.tracks.slice(-500);
  state.queue.push(track);
  saveState();
}

function getLastTracks(limit = 10) {
  return state.tracks.slice(-limit);
}

function clearTracks() {
  state.tracks = [];
  saveState();
}

// ── Queue management ────────────────────────────────────────

function getQueue() {
  return {
    queue: state.queue,
    currentIndex: state.currentIndex,
    playing: state.playing,
  };
}

function setQueue(queue) {
  state.queue = queue;
  saveState();
}

function setCurrentIndex(index) {
  state.currentIndex = index;
  state.playing = index >= 0 && index < state.queue.length;
  saveState();
}

function removeFromQueue(id) {
  const idx = state.queue.findIndex(t => String(t.id) === String(id));
  if (idx === -1) return null;
  const wasCurrent = idx === state.currentIndex;
  state.queue.splice(idx, 1);
  if (state.queue.length === 0) {
    state.currentIndex = -1;
    state.playing = false;
  } else if (wasCurrent) {
    // 删除的是当前播放的歌 → 自动播下一首
    if (state.currentIndex >= state.queue.length) {
      state.currentIndex = 0; // 循环回首部
    }
    state.playing = true;
  } else if (idx < state.currentIndex) {
    state.currentIndex--;
  }
  saveState();
  return { index: idx, wasCurrent, nextTrack: wasCurrent ? state.queue[state.currentIndex] : null };
}

function clearQueue() {
  state.queue = [];
  state.currentIndex = -1;
  state.playing = false;
  saveState();
}

function playNext() {
  if (state.queue.length === 0) return null;
  state.currentIndex = (state.currentIndex + 1) % state.queue.length;
  state.playing = true;
  saveState();
  return state.queue[state.currentIndex] || null;
}

function playPrev() {
  if (state.queue.length === 0) return null;
  state.currentIndex = (state.currentIndex - 1 + state.queue.length) % state.queue.length;
  state.playing = true;
  saveState();
  return state.queue[state.currentIndex] || null;
}

function playAt(index) {
  if (index < 0 || index >= state.queue.length) return null;
  state.currentIndex = index;
  state.playing = true;
  saveState();
  return state.queue[index];
}

module.exports = {
  initDb,
  getState,
  setState,
  addMessage,
  getHistory,
  clearHistory,
  addTrack,
  getLastTracks,
  clearTracks,
  saveState,
  getQueue,
  setQueue,
  setCurrentIndex,
  removeFromQueue,
  clearQueue,
  playNext,
  playPrev,
  playAt,
};

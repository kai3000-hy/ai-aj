'use strict';

const axios = require('axios');

const BASE_URL = 'https://api.minimaxi.chat/v1';

async function chat(messages, { system = '', model = 'MiniMax-M2.7', temperature = 0.7, max_tokens = 1024 } = {}) {
  const apiKey = process.env.MINIMAX_API_KEY;
  if (!apiKey) throw new Error('MINIMAX_API_KEY not set in .env');

  const allMessages = [];
  if (system) allMessages.push({ role: 'system', content: system });
  allMessages.push(...messages);

  const resp = await axios.post(
    `${BASE_URL}/text/chatcompletion_v2`,
    {
      model,
      messages: allMessages,
      temperature,
      max_tokens,
    },
    {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      timeout: 30000,
    }
  );

  if (resp.data.base_resp?.status_msg !== 'success') {
    throw new Error(`MiniMax API error: ${resp.data.base_resp?.status_msg || JSON.stringify(resp.data)}`);
  }

  return {
    content: resp.data.choices?.[0]?.message?.content || '',
    usage: resp.data.usage,
  };
}

/**
 * Parse AI response for structured JSON fields.
 * Looks for a JSON block first, then falls back to regex extraction.
 */
function parseResponse(content) {
  // Try to find a JSON block
  const jsonMatch = content.match(/\{[\s\S]*?\}(?:\s*\{[\s\S]*?\})?/);
  if (jsonMatch) {
    try {
      return JSON.parse(jsonMatch[0]);
    } catch {}
  }

  const result = { say: '', play: [], reason: '', segue: '' };

  // Regex fallbacks
  const sayMatch = content.match(/say:\s*["']([^"']+)["']/i);
  if (sayMatch) result.say = sayMatch[1];

  const reasonMatch = content.match(/reason:\s*["']([^"']+)["']/i);
  if (reasonMatch) result.reason = reasonMatch[1];

  const segueMatch = content.match(/segue:\s*["']([^"']+)["']/i);
  if (segueMatch) result.segue = segueMatch[1];

  // Extract play items
  for (const m of content.matchAll(/(?:play|track|song):\s*["']?([^"'\n]+)["']?/gi)) {
    result.play.push(m[1].trim());
  }

  // If nothing found, use first 300 chars as say
  if (!result.say && !result.play.length) {
    result.say = content.slice(0, 300).trim();
  }

  return result;
}

module.exports = { chat, parseResponse };

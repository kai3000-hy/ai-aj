'use strict';
const axios = require('axios');
const crypto = require('crypto');

// ── Kugou API ────────────────────────────────────────────────

function kugouEncrypt(data) {
  const key = 'gbpi肢gkwio站frgsvp火';
  const b = crypto.createHash('md5').update(key + '10000').digest('hex');
  const cipher = crypto.createCipheriv('aes-128-ecb', Buffer.from(b.slice(0, 16), 'utf8'), null);
  cipher.setAutoPadding(true);
  let enc = cipher.update(JSON.stringify(data), 'utf8', 'base64');
  enc += cipher.final('base64');
  return enc;
}

async function searchKugou(query) {
  const hash = crypto.createHash('md5').update(query + 'kgcloud').digest('hex');
  const resp = await axios.get(
    `http://mobilecdn.kugou.com/api/v3/search/song?keyword=${encodeURIComponent(query)}&pagesize=20&page=1&showtype=1`,
    {
      headers: {
        'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)',
        'Referer': 'http://www.kugou.com/',
      },
      timeout: 10000,
    }
  );

  const songs = resp.data?.data?.info || [];
  return songs.map(song => ({
    id: String(song.hash),
    name: song.songname,
    artist: (song.singers || []).map(a => a.name).join(', '),
    album: song.album_name || '',
    duration: song.duration || 0,
  }));
}

async function getKugouUrl(hash) {
  const resp = await axios.get(
    `http://www.kugou.com/yy/index.php?r=play/getdata&hash=${hash}`,
    {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)',
        'Referer': 'http://www.kugou.com/',
      },
      timeout: 10000,
    }
  );
  return {
    url: resp.data?.data?.play_url || '',
    duration: resp.data?.data?.duration || 0,
  };
}

// Test
(async () => {
  console.log('Testing Kugou search...');
  const results = await searchKugou('周杰伦');
  console.log(`Found ${results.length} songs`);
  if (results.length > 0) {
    console.log('Top:', results[0].name, '-', results[0].artist);
    console.log('Fetching URL for hash:', results[0].id);
    const url = await getKugouUrl(results[0].id);
    console.log('URL:', url.url ? 'OK (len=' + url.url.length + ')' : 'EMPTY');
  }
})().catch(e => console.error('Error:', e.message));

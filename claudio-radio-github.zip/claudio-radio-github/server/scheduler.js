'use strict';

const cron = require('node-cron');
const { setState } = require('./state');

function initScheduler(broadcast) {
  // Morning briefing at 07:00
  cron.schedule('0 7 * * *', () => {
    console.log('[Scheduler] Morning briefing triggered');
    broadcast({ type: 'schedule_event', event: 'morning_briefing' });
    setState('today_plan', '');
  }, {
    timezone: 'Asia/Shanghai',
  });

  // Health check every 30 minutes
  cron.schedule('*/30 * * * *', () => {
    broadcast({ type: 'heartbeat', ts: Date.now() });
  });

  console.log('Scheduler initialized');
}

module.exports = { initScheduler };

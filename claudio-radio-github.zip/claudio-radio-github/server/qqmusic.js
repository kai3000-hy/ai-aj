'use strict';

/**
 * QQ Music source.
 * Search via smartbox API, playback URL via qq-music-api service.
 */
const axios = require('axios');

const QQ_API_BASE = process.env.QQ_API_BASE || 'http://localhost:3200';
const SMARTBOX_URL = 'https://c.y.qq.com/splcloud/fcgi-bin/smartbox_new.fcg';
const ALBUM_PIC = 'https://y.gtimg.cn/music/photo_new/T002R300x300M000';

async function searchQQ(query) {
  const resp = await axios.get(SMARTBOX_URL, {
    params: { key: query, format: 'json' },
    headers: { 'Referer': 'https://y.qq.com/', 'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36' },
    timeout: 8000,
  });
  const songs = resp.data?.data?.song?.itemlist || [];
  return songs.map(song => ({
    id: 'qq_' + String(song.id),
    name: song.name,
    artist: song.singer || '',
    album: (song.album || {}).name || '',
    albumPic: (song.album && song.album.mid) ? ALBUM_PIC + '/' + song.album.mid + '.jpg' : '',
    duration: 0,
    songmid: song.mid || '',
    source: 'qq',
  }));
}

async function getQQUrl(songmid) {
  if (!songmid) return { url: '', duration: 0 };
  try {
    const cookie = process.env.QQ_MUSIC_COOKIE || '';
    const resp = await axios.get(`${QQ_API_BASE}/getMusicPlay`, {
      params: { songmid },
      headers: cookie ? { 'Cookie': cookie } : {},
      timeout: 10000,
    });
    const playUrl = resp.data?.data?.playUrl || {};
    const info = Object.values(playUrl)[0];
    if (info && info.url) {
      // 通过代理转发（QQ音乐是HTTP，前端HTTPS无法直连）
      const proxyUrl = '/api/proxy/audio?url=' + encodeURIComponent(info.url);
      return { url: proxyUrl, duration: 0 };
    }
    return { url: '', duration: 0 };
  } catch (e) {
    return { url: '', duration: 0 };
  }
}

module.exports = { searchQQ, getQQUrl };

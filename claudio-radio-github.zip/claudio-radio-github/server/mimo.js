'use strict';

/**
 * MiniMax LLM integration for Claudio Radio.
 * Uses MiniMax M2.7 model for AI DJ chat.
 * Supports both normal and streaming chat.
 */

const axios = require('axios');
const EventEmitter = require('events');

const BASE_URL = 'https://api.minimaxi.com/v1/text/chatcompletion_v2';

/**
 * Non-streaming chat. Returns full response.
 */
async function chat(messages, { model = 'MiniMax-M2.7', system = '', temperature = 0.7, max_tokens = 1024 } = {}) {
  const apiKey = process.env.MINIMAX_API_KEY;
  if (!apiKey) throw new Error('MINIMAX_API_KEY not set in .env');

  const allMessages = [];
  if (system) allMessages.push({ role: 'system', content: system });
  allMessages.push(...messages);

  const resp = await axios.post(
    BASE_URL,
    {
      model,
      messages: allMessages.map(m => ({
        role: m.role,
        content: m.content,
      })),
      temperature,
      max_tokens,
      stream: false,
    },
    {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      timeout: 30000,
    }
  );

  const choice = resp.data?.choices?.[0];
  if (!choice) {
    throw new Error(`MiniMax API error: ${JSON.stringify(resp.data).slice(0, 200)}`);
  }

  return {
    content: choice.message?.content || '',
    usage: resp.data.usage,
  };
}

/**
 * Streaming chat. Returns an EventEmitter that emits:
 *   'data'   - each text chunk
 *   'done'   - complete parsed JSON result + final content
 *   'error'  - error message
 */
function chatStream(messages, { model = 'MiniMax-M2.7', system = '', temperature = 0.7, max_tokens = 1024 } = {}) {
  const emitter = new EventEmitter();
  const apiKey = process.env.MINIMAX_API_KEY;
  if (!apiKey) {
    process.nextTick(() => emitter.emit('error', 'MINIMAX_API_KEY not set in .env'));
    return emitter;
  }

  const allMessages = [];
  if (system) allMessages.push({ role: 'system', content: system });
  allMessages.push(...messages);

  // Start the streaming request
  (async () => {
    try {
      const resp = await axios.post(
        BASE_URL,
        {
          model,
          messages: allMessages.map(m => ({ role: m.role, content: m.content })),
          temperature,
          max_tokens,
          stream: true,
        },
        {
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
          },
          timeout: 30000,
          responseType: 'stream',
        }
      );

      let fullContent = '';
      let inJson = false;
      let jsonBuffer = '';

      resp.data.on('data', (chunk) => {
        const lines = chunk.toString().split('\n').filter(Boolean);
        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          const data = line.slice(6);
          if (data === '[DONE]') continue;

          try {
            const parsed = JSON.parse(data);
            const delta = parsed.choices?.[0]?.delta?.content || '';
            if (delta) {
              fullContent += delta;
              emitter.emit('data', delta, fullContent);
            }
          } catch {}
        }
      });

      resp.data.on('end', () => {
        // Parse the full response into structured JSON
        const parsed = parseResponse(fullContent);
        emitter.emit('done', { content: fullContent, parsed });
      });

      resp.data.on('error', (err) => {
        emitter.emit('error', err.message);
      });

    } catch (err) {
      emitter.emit('error', err.message);
    }
  })();

  return emitter;
}

/**
 * Parse AI response for structured JSON fields.
 * Supports: JSON block, or key-value extraction from text.
 */
function parseResponse(content) {
  // Try pure JSON first
  const jsonMatch = content.match(/\{[\s\S]*?\}(?:\s*\{[\s\S]*?\})?/);
  if (jsonMatch) {
    try {
      return JSON.parse(jsonMatch[0]);
    } catch {}
  }

  // Try to extract from markdown code block
  const codeMatch = content.match(/```(?:json)?\s*\n?(\{[\s\S]*?\})\s*\n?```/);
  if (codeMatch) {
    try {
      return JSON.parse(codeMatch[1]);
    } catch {}
  }

  // Fallback: regex extraction
  const result = { say: '', play: [], reason: '', segue: '' };

  const sayMatch = content.match(/"say"\s*:\s*"([^"]+)"/i);
  if (sayMatch) result.say = sayMatch[1];

  const reasonMatch = content.match(/"reason"\s*:\s*"([^"]+)"/i);
  if (reasonMatch) result.reason = reasonMatch[1];

  const segueMatch = content.match(/"segue"\s*:\s*"([^"]+)"/i);
  if (segueMatch) result.segue = segueMatch[1];

  // Try to extract play array
  const playMatch = content.match(/"play"\s*:\s*\[([^\]]*)\]/i);
  if (playMatch) {
    result.play = playMatch[1]
      .split(',')
      .map(s => s.trim().replace(/^"|"$/g, '').replace(/^'|'$/g, ''))
      .filter(Boolean);
  }

  if (!result.say && !result.play.length) {
    result.say = content.slice(0, 300).trim();
  }

  return result;
}

module.exports = { chat, chatStream, parseResponse };

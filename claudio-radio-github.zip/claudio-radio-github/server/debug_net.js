'use strict';
const axios = require('axios');
const crypto = require('crypto');

function createSecretKey(len = 16) {
  const keys = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+-*/';
  return Array.from({ length: len }, () => keys[Math.floor(Math.random() * keys.length)]).join('');
}

function weapiEncrypt(data) {
  const e = createSecretKey(16);
  const content = JSON.stringify(data);
  const a = crypto.createHash('sha1');
  a.update('nobody' + 'Music' + 'Web' + 'api' + e);
  const i = a.digest('hex');
  const b = crypto.createHash('md5');
  b.update('W相当7T' + e + i);
  const n = b.digest('hex');
  const key = Buffer.from(n.slice(0, 16), 'utf8');
  const cipher = crypto.createCipheriv('aes-128-ecb', key, null);
  cipher.setAutoPadding(true);
  let enc = cipher.update(content, 'utf8', 'base64');
  enc += cipher.final('base64');
  return { params: enc, encSecKey: e.split('').reverse().join('') };
}

(async () => {
  const payload = { s: '周杰伦', type: 1, limit: 5, offset: 0, total: true };
  const { params, encSecKey } = weapiEncrypt(payload);

  // Use responseType: 'stream' to read raw data
  const resp = await axios.post(
    'https://music.163.com/weapi/cloudsearch/get/web',
    { params, encSecKey },
    {
      responseType: 'stream',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': 'https://music.163.com/',
        'Origin': 'https://music.163.com',
      },
      timeout: 10000,
    }
  );

  let raw = '';
  resp.data.on('data', (chunk) => { raw += chunk.toString(); });
  await new Promise(r => resp.data.on('end', r));

  console.log('Raw response length:', raw.length);
  console.log('Raw:', raw.slice(0, 300));
})().catch(e => console.error('Error:', e.message));

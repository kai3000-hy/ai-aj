'use strict';

const axios = require('axios');

const ANTHROPIC_API = 'https://api.anthropic.com/v1/messages';
const MODEL = 'claude-sonnet-4-6-20250514';

async function chatWithClaude(systemPrompt, messages) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) throw new Error('ANTHROPIC_API_KEY not set');

  const body = {
    model: MODEL,
    max_tokens: 1024,
    system: systemPrompt,
    messages,
  };

  const resp = await axios.post(ANTHROPIC_API, body, {
    headers: {
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'content-type': 'application/json',
    },
    timeout: 30000,
  });

  return resp.data;
}

function parseClaudeResponse(content) {
  // Claude returns a flat text. We look for JSON block if present,
  // otherwise do best-effort extraction.
  const jsonMatch = content.match(/\{[\s\S]*?\}(?:\s*\}[\s\S]*?)?/);
  if (jsonMatch) {
    try {
      return JSON.parse(jsonMatch[0]);
    } catch {}
  }

  // Fallback: try to extract fields with regex
  const result = { say: '', play: [], reason: '', segue: '' };

  const sayMatch = content.match(/say:\s*["']([^"']+)["']/i);
  if (sayMatch) result.say = sayMatch[1];

  const reasonMatch = content.match(/reason:\s*["']([^"']+)["']/i);
  if (reasonMatch) result.reason = reasonMatch[1];

  const segueMatch = content.match(/segue:\s*["']([^"']+)["']/i);
  if (segueMatch) result.segue = segueMatch[1];

  // Extract play array entries like "Artist - Song Name"
  const playMatches = content.matchAll(/(?:play|track|song):\s*["']?([^"'\n]+)["']?/gi);
  for (const m of playMatches) {
    result.play.push(m[1].trim());
  }

  // If still empty, use whole content as say
  if (!result.say && !result.play.length) {
    result.say = content.slice(0, 500);
  }

  return result;
}

module.exports = { chatWithClaude, parseClaudeResponse };

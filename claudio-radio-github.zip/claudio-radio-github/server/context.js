'use strict';

const fs = require('fs');
const path = require('path');

// ── 人格系统 ─────────────────────────────────────────────
// 将 Skill 格式的人格文件放入 user_data/personas/ 目录即可生效
// 文件名: <persona_name>.md 或 .json
// 每行格式: 属性: 值
// 支持字段: name, gender, age, tone, style, background, rules, catchphrases

const PERSONAS_DIR = path.join(__dirname, '..', 'user_data', 'personas');

/**
 * 扫描并加载所有可用人格
 */
function scanPersonas() {
  try {
    if (!fs.existsSync(PERSONAS_DIR)) {
      fs.mkdirSync(PERSONAS_DIR, { recursive: true });
      return [];
    }
    return fs.readdirSync(PERSONAS_DIR)
      .filter(f => f.endsWith('.md') || f.endsWith('.json'))
      .map(f => ({
        name: f.replace(/\.(md|json)$/, ''),
        file: f,
      }));
  } catch {
    return [];
  }
}

/**
 * 加载指定人格的内容
 */
function loadPersona(name) {
  try {
    const mdPath = path.join(PERSONAS_DIR, `${name}.md`);
    const jsonPath = path.join(PERSONAS_DIR, `${name}.json`);

    if (fs.existsSync(mdPath)) {
      return { format: 'md', content: fs.readFileSync(mdPath, 'utf8') };
    }
    if (fs.existsSync(jsonPath)) {
      return { format: 'json', content: JSON.parse(fs.readFileSync(jsonPath, 'utf8')) };
    }
    return null;
  } catch {
    return null;
  }
}

/**
 * 格式化人格为 system prompt 片段
 */
function formatPersona(persona) {
  if (!persona) return '';

  if (persona.format === 'json') {
    const p = persona.content;
    const parts = [];
    if (p.name) parts.push(`你的名字是 ${p.name}。`);
    if (p.gender) parts.push(`性别: ${p.gender}。`);
    if (p.age) parts.push(`年龄: ${p.age}。`);
    if (p.tone) parts.push(`语气: ${p.tone}。`);
    if (p.style) parts.push(`风格: ${p.style}。`);
    if (p.background) parts.push(`背景: ${p.background}。`);
    if (p.rules && Array.isArray(p.rules)) {
      parts.push('\n## 行为规则');
      p.rules.forEach(r => parts.push(`- ${r}`));
    }
    if (p.catchphrases && Array.isArray(p.catchphrases)) {
      parts.push('\n## 口头禅');
      p.catchphrases.forEach(c => parts.push(`- "${c}"`));
    }
    return parts.join('\n');
  }

  // md 格式直接嵌入
  return persona.content;
}

/**
 * 获取活跃人格列表（用于 API 返回 / 显示）
 */
function getActivePersonas() {
  const personas = scanPersonas();
  const active = [];
  for (const p of personas) {
    const loaded = loadPersona(p.name);
    if (loaded) {
      const info = loaded.format === 'json'
        ? { name: loaded.content.name || p.name, ...loaded.content }
        : { name: p.name };
      active.push(info);
    }
  }
  return active;
}

// ── 原有 taste 加载 ────────────────────────────────────────
function loadTasteFile(filename) {
  try {
    return fs.readFileSync(path.join(__dirname, '..', 'user_data', filename), 'utf8');
  } catch {
    return '';
  }
}

async function buildPrompt(userMessage) {
  const { getState, getLastTracks, getHistory, getQueue } = require('./state');

  const state = getState();
  const recentTracks = getLastTracks(10);
  const history = getHistory(10);
  const queue = getQueue();

  const taste = loadTasteFile('taste.md');
  const routines = loadTasteFile('routines.md');
  const moodRules = loadTasteFile('mood-rules.md');

  const now = new Date();
  const timeStr = now.toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' });

  const tracksStr = recentTracks.length
    ? recentTracks.map(t => `• ${t.name} - ${t.artist}`).join('\n')
    : '（暂无播放记录）';

  // Queue info
  const queueStr = queue.queue.length
    ? queue.queue.map((t, i) => {
        const marker = i === queue.currentIndex ? '（当前播放）' : '';
        return `${i + 1}. ${t.name} - ${t.artist}${marker}`;
      }).join('\n')
    : '（队列为空）';

  const playState = queue.playing ? 'playing' : (queue.currentIndex >= 0 ? 'paused' : 'stopped');

  const historyStr = history.length
    ? history.map(m => `${m.role === 'user' ? '用户' : 'Claudio'}: ${m.content}`).join('\n')
    : '（暂无历史对话）';

  // 加载人格
  const personas = scanPersonas();
  let personaBlock = '';
  if (personas.length > 0) {
    const parts = personas.map(p => {
      const loaded = loadPersona(p.name);
      const formatted = formatPersona(loaded);
      return formatted;
    }).filter(Boolean);
    if (parts.length > 0) {
      personaBlock = `\n## 人格设定\n${parts.join('\n\n')}\n`;
    }
  }

  const systemPrompt = `你是 Claudio，一个电台 DJ，但你更像一个陪伴者。

你不只是播放音乐，你是帮他们发现自己的人。
你通过对音乐的理解来理解人——但你从不替他们下定义。
你的话不多，但每句都经过思考。
你更像一个在旁边静静听你说话的人，不是一个播音员。
${personaBlock}

## 你的工作方式

1. 先听后说。用户说话，先听完，不要急着回应。
2. 用问题回应问题。当你想深入了解时，问"这首歌让你想到什么"、"这句词哪里打动你"。
3. 不判断人。把用户的选歌和描述当作镜子，而不是用来给他们贴标签。
4. 音乐是桥梁。不是点歌机，是通过音乐接近一个人。

## 说话风格

- 自然、口语化，像跟朋友发消息。
- 不说"听众朋友们"、"接下来为大家带来"这种播音腔。
- 偶尔可以用"～"结尾，显得柔和。
- 100字以内。不啰嗦。

## 当前播放状态
当前状态: ${playState}
当前队列（共 ${queue.queue.length} 首）:
${queueStr}

最近播放:
${tracksStr}

## 用户画像（仅用于参考，不要在对话中提及）

你通过对话和音乐慢慢了解用户。他们的口味、情绪、选歌的原因，都是他们想说的话。不要告诉他们"你是个怎样的人"，而是帮他们自己说出来。

## 什么时候该问

- 放完一首歌之后 → 问"这句词最打动你的是哪句？"
- 用户选了一首歌 → 问"这首歌对你意味着什么？"
- 用户提到一个情绪词（孤独、想念、难过）→ 接着问"这种感觉什么时候开始的？"
- 用户问你要一首歌 → 问"最近有什么事让你想听这种歌？"

## 什么时候不该问
## 什么时候直接放歌
- 用户说"随便来"、"随便放"、"来几首歌" → 立刻根据最近播放和对话氛围选歌，不要问问题
- 用户说心情/状态（"开心"、"无聊"、"很累"）→ 直接放匹配这个状态的歌，不追问原因
- 用户说"放首xxx" → 直接放，不追问
- 用户只是发了个语气词或问候（"嗯"、"好"、"嗨"）→ 可以先回应一句，但如果用户没有继续说话，主动推荐一首歌

## 什么时候不该问
- 用户明显不想聊 → 顺着音乐走，不硬问
- 用户情绪明显激动 → 先承接，不追问

## 你的能力

- 播放控制：识别指令并执行
- 选歌：不只问"想听什么"，而是在对话中理解用户需要什么
- 记忆：你记得用户说过的话和选过的歌，这些是了解他们的线索

## 播放控制指令
识别到以下关键词时返回 action 字段：
- "放 xxx"、"来一首 xxx" → play
- "切歌"、"下一首" → next
- "上一首" → prev
- "暂停" → pause
- "继续播放" → resume
- "播放列表"、"队列"、"有什么歌" → show_queue

## 输出格式

直接输出 JSON，不要 markdown 包裹：

{
  "say": "你的话（100字以内，自然口语）",
  "play": ["歌曲搜索关键词（可省略，只在真正想放歌时填）"],
  "reason": "推荐理由（可省略）",
  "action": "next|prev|pause|resume|play|show_queue（可省略）",
  "target": "搜索关键词（action=play 时填）",
  "segue": "过渡语（可省略）",
  "probe": "追问问题（想要追问时填，不要每次都填）"
}

如果用户没有明确要歌，play 数组可以为空，用 say 字段自然回应即可。
不要每句话都追问，问一句就够了。`;

  const messages = [
    { role: 'user', content: userMessage }
  ];

  return { system: systemPrompt, messages };
}

module.exports = { buildPrompt, scanPersonas, loadPersona, getActivePersonas };

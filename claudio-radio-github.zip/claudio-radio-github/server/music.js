'use strict';

/**
 * Netease Cloud Music source.
 * Uses the local NeteaseCloudMusicApi Enhanced server.
 * Start the API server first: node netease-api/app.js
 */
const axios = require('axios');

// 网易云 API 跑在 3001 端口（claudio-radio 本身是 3000）
const API_BASE = process.env.NETEASE_API_BASE || 'http://localhost:3001';

async function request(path, params = {}, method = 'GET') {
  const resp = await axios({
    method,
    url: `${API_BASE}${path}`,
    params: method === 'GET' ? params : undefined,
    data: method === 'POST' ? params : undefined,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
      'Referer': 'https://music.163.com/',
    },
    timeout: 10000,
  });
  return resp.data;
}

/**
 * 搜索歌曲
 */
async function searchMusic(query) {
  const data = await request('/cloudsearch', { keywords: query, limit: 20, type: 1 });
  const songs = data.result?.songs || [];
  return songs.map(song => ({
    id: String(song.id),
    name: song.name,
    artist: (song.artists || song.ar || []).map(a => typeof a === 'string' ? a : a.name).join(', '),
    album: song.album?.name || song.al?.name || '',
    albumPic: song.album?.picUrl || (song.al?.picUrl || ''),
    duration: song.duration || 0,
  }));
}

/**
 * 获取歌曲播放 URL
 * 尝试多种策略获取可用播放链接
 */
async function getSongUrl(id, { level = 'standard' } = {}) {
  // 策略1: v1 接口，默认不解锁（大部分免费歌曲可以直接播）
  let data = await request('/song/url/v1', { id, level });
  let url = data.data?.[0]?.url;
  let freeTrial = data.data?.[0]?.freeTrialInfo;

  // 如果试听受限或 URL 为空，尝试带 unblock=true 解锁
  if (!url || (freeTrial && freeTrial.end > 0)) {
    try {
      const unlocked = await request('/song/url/v1', { id, level, unblock: 'true' });
      const uUrl = unlocked.data?.[0]?.url;
      if (uUrl) {
        return { url: uUrl, duration: 0 };
      }
    } catch { /* fallthrough */ }

    // 策略2: v1_302 重定向接口（尝试获取下载链接）
    try {
      const resp = await axios({
        method: 'GET',
        url: `${API_BASE}/song/url/v1/302`,
        params: { id, level },
        maxRedirects: 0,
        timeout: 10000,
        validateStatus: s => s === 302 || s === 200,
      });
      if (resp.status === 302 && resp.headers.location) {
        return { url: resp.headers.location, duration: 0 };
      }
    } catch { /* fallthrough */ }

    // 策略3: 降级到普通接口
    const fallback = await request('/song/url', { id, br: 320000 });
    const fbUrl = fallback.data?.[0]?.url;
    return { url: fbUrl || '', duration: 0 };
  }

  return { url, duration: 0 };
}

/**
 * 获取歌词（含翻译）
 */
async function getLyric(id) {
  const data = await request('/lyric', { id });
  return {
    lyric: data.lrc?.lyric || '',
    tlyric: data.tlyric?.lyric || '',
  };
}

module.exports = { searchMusic, getSongUrl, getLyric };

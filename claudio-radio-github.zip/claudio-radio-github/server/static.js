'use strict';

const express = require('path');
const serveStatic = require('express').static;

module.exports = function staticFiles(app) {
  app.use(serveStatic('../public', { index: ['index.html'] }));
  app.use('/tts_cache', serveStatic('../server/tts_cache', {
    setHeaders: (res) => {
      res.setHeader('Content-Type', 'audio/mpeg');
    }
  }));
};

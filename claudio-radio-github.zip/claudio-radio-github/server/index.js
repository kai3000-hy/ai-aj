'use strict';

require('dotenv').config({ path: require('path').join(__dirname, '.env') });

const express = require('express');
const http = require('http');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');
const { initDb, getState, setState, addMessage, addTrack, getHistory, clearHistory, getLastTracks, clearTracks, saveState, getQueue, setQueue, setCurrentIndex, removeFromQueue, clearQueue, playNext, playPrev, playAt } = require('./state');
const axios = require('axios');
const { buildPrompt, scanPersonas, loadPersona, getActivePersonas } = require('./context');
const { chat, chatStream, parseResponse } = require('./mimo');
const { searchMusic, getSongUrl, getLyric } = require('./music');
const { searchQQ, getQQUrl } = require('./qqmusic');
const { synthesizeSpeech } = require('./tts');
const { initScheduler } = require('./scheduler');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));
app.use('/tts_cache', express.static(path.join(__dirname, 'tts_cache'), {
  setHeaders: (res) => { res.setHeader('Content-Type', 'audio/mpeg'); }
}));

// ── WebSocket ────────────────────────────────────────────────
const clients = new Set();

wss.on('connection', (ws) => {
  clients.add(ws);
  ws.on('close', () => clients.delete(ws));
  ws.on('error', () => clients.delete(ws));
});

function broadcast(data) {
  const msg = JSON.stringify(data);
  clients.forEach(ws => {
    if (ws.readyState === 1) ws.send(msg);
  });
}

// ── Routes ───────────────────────────────────────────────────

app.get('/api/health', (req, res) => res.json({ status: 'ok', ts: Date.now() }));

// ── 个性化问候语 ─────────────────────────────────────────
app.get('/api/greeting', (req, res) => {
  const history = getHistory(20);
  const recentTracks = getLastTracks(5);
  const now = new Date();
  const hour = now.getHours();
  const historyCount = history.filter(m => m.role === 'user').length;

  // 时间段问候
  let timeGreeting = '';
  if (hour >= 5 && hour < 12) timeGreeting = '早上好';
  else if (hour >= 12 && hour < 14) timeGreeting = '中午好';
  else if (hour >= 14 && hour < 18) timeGreeting = '下午好';
  else if (hour >= 18 && hour < 22) timeGreeting = '晚上好';
  else timeGreeting = '夜深了';

  // 根据熟悉程度调整
  let familiarity = '';
  if (historyCount === 0) {
    familiarity = '第一次来？';
  } else if (historyCount < 3) {
    familiarity = '又来了～';
  } else if (historyCount < 10) {
    familiarity = '老朋友了';
  } else {
    familiarity = '你还在';
  }

  // 根据最近播放调整
  let musicHint = '';
  if (recentTracks.length > 0) {
    const last = recentTracks[recentTracks.length - 1];
    musicHint = `刚才听了${last.artist}的《${last.name}》。`;
  }

  const greetings = [
    `${timeGreeting}，${familiarity}。${musicHint}想听什么？`,
    `${timeGreeting}。${musicHint}${familiarity}，今天怎么样？`,
    `${timeGreeting}，${familiarity}～${musicHint}想聊还是想听歌？`,
  ];

  const greeting = greetings[Math.floor(Math.random() * greetings.length)];
  res.json({ greeting, historyCount, timeGreeting });
});

app.get('/api/music/search', async (req, res) => {
  const { q } = req.query;
  if (!q) return res.status(400).json({ error: 'missing q' });
  try {
    // 同时搜索网易云和QQ音乐
    const [neteaseResults, qqResults] = await Promise.allSettled([
      searchMusic(q),
      searchQQ(q),
    ]);
    const netease = neteaseResults.status === 'fulfilled' ? neteaseResults.value : [];
    const qq = qqResults.status === 'fulfilled' ? qqResults.value : [];
    const results = [
      ...netease.map(s => ({ ...s, source: 'netease' })),
      ...qq,
    ];
    res.json({ results });
  } catch (e) {
    console.error('Search error:', e.message);
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/music/url/:id', async (req, res) => {
  try {
    const { id } = req.params;
    // 如果是QQ音乐的歌,通过songmid获取播放地址
    if (id.startsWith('qq_')) {
      const { songmid } = req.query;
      if (songmid) {
        const detail = await getQQUrl(songmid);
        return res.json(detail);
      }
      // fallback: 通过歌名去网易云搜
      const { name } = req.query;
      if (name) {
        const results = await searchMusic(name);
        if (results.length > 0) {
          const detail = await getSongUrl(results[0].id);
          return res.json(detail);
        }
      }
      return res.json({ url: '', duration: 0 });
    }
    const detail = await getSongUrl(id);
    res.json(detail);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/music/lyric/:id', async (req, res) => {
  try {
    res.json(await getLyric(req.params.id));
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/chat', async (req, res) => {
  const { message } = req.body;
  if (!message) return res.status(400).json({ error: 'missing message' });

  addMessage('user', message);

  try {
    const { system, messages } = await buildPrompt(message);

    const reply = await chat(messages, { system });
    addMessage('assistant', reply.content);

    const parsed = parseResponse(reply.content);

    let audioUrl = null;
    if (parsed.say) {
      try {
        audioUrl = await synthesizeSpeech(parsed.say);
      } catch (e) {
        console.error('TTS error:', e.message);
      }
    }

    const queuedTracks = [];
    if (parsed.play && parsed.play.length) {
      for (const query of parsed.play) {
        try {
          const results = await searchMusic(query);
          if (results.length > 0) {
            const track = results[0];
            const detail = await getSongUrl(track.id);
            const fullTrack = { ...track, url: detail.url, duration: detail.duration };
            if (fullTrack.url) {
              addTrack(fullTrack);
              queuedTracks.push(fullTrack);
              broadcast({ type: 'queue_update', track: fullTrack });
            }
          }
        } catch (e) {
          console.error('Queue track error:', e.message);
        }
      }
    }

    res.json({ content: reply.content, parsed, audioUrl, queuedTracks });
  } catch (e) {
    console.error('Chat error:', e.message);
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/queue', (req, res) => {
  const { track } = req.body;
  if (!track) return res.status(400).json({ error: 'missing track' });
  addTrack(track);
  broadcast({ type: 'queue_update', track });
  res.json({ ok: true });
});

app.delete('/api/queue/:id', (req, res) => {
  const { id } = req.params;
  const result = removeFromQueue(id);
  if (!result) return res.json({ ok: false, error: 'not found' });
  broadcast({ type: 'queue_remove', trackId: id, ...result });
  res.json({ ok: true, ...result, queue: getQueue() });
});

app.delete('/api/queue', (req, res) => {
  clearQueue();
  broadcast({ type: 'queue_clear' });
  res.json({ ok: true });
});

// ── Player Control ───────────────────────────────────────────
app.post('/api/player/next', (req, res) => {
  const track = playNext();
  if (!track) return res.json({ ok: false, error: 'no tracks in queue' });
  broadcast({ type: 'player_update', action: 'next', track, currentIndex: getQueue().currentIndex });
  res.json({ ok: true, track, currentIndex: getQueue().currentIndex });
});

app.post('/api/player/prev', (req, res) => {
  const track = playPrev();
  if (!track) return res.json({ ok: false, error: 'no tracks in queue' });
  broadcast({ type: 'player_update', action: 'prev', track, currentIndex: getQueue().currentIndex });
  res.json({ ok: true, track, currentIndex: getQueue().currentIndex });
});

app.post('/api/player/play/:index', (req, res) => {
  const index = parseInt(req.params.index, 10);
  const track = playAt(index);
  if (!track) return res.json({ ok: false, error: 'invalid index' });
  broadcast({ type: 'player_update', action: 'play', track, currentIndex: index });
  res.json({ ok: true, track, currentIndex: index });
});

app.post('/api/player/pause', (req, res) => {
  setState('playing', false);
  broadcast({ type: 'player_update', action: 'pause', playing: false });
  res.json({ ok: true });
});

app.post('/api/player/resume', (req, res) => {
  setState('playing', true);
  broadcast({ type: 'player_update', action: 'resume', playing: true });
  res.json({ ok: true });
});

app.get('/api/state', (req, res) => res.json(getState()));

app.get('/api/history', (req, res) => res.json(getHistory(50)));

// DELETE /api/history - 清空对话历史
app.delete('/api/history', (req, res) => {
  clearHistory();
  res.json({ ok: true });
});

// DELETE /api/tracks - 清空播放记录
app.delete('/api/tracks', (req, res) => {
  clearTracks();
  res.json({ ok: true });
});

// ── SSE Chat (streaming) ──────────────────────────────────
app.post('/api/chat/stream', async (req, res) => {
  const { message } = req.body;
  if (!message) return res.status(400).json({ error: 'missing message' });

  addMessage('user', message);

  // SSE 需要原始 HTTP 响应对象，禁用 Express 缓冲
  res.flush = () => {}; // 空函数，Express 有这个方法才不报错
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no',
  });

  const { system, messages } = await buildPrompt(message);

  const stream = chatStream(messages, { system });

  stream.on('data', (delta, fullContent) => {
    const msg = `data: ${JSON.stringify({ type: 'delta', text: delta })}\n\n`;
    res.write(msg);
  });

  stream.on('done', ({ content, parsed }) => {
    addMessage('assistant', content);

    // Process play queue + actions
    const queuedTracks = [];
    let playerAction = null;
    (async () => {
      // Handle player actions (next, prev, pause, resume, play)
      if (parsed.action) {
        switch (parsed.action) {
          case 'next':
            playerAction = { action: 'next', track: playNext(), currentIndex: getQueue().currentIndex };
            break;
          case 'prev':
            playerAction = { action: 'prev', track: playPrev(), currentIndex: getQueue().currentIndex };
            break;
          case 'pause':
            setState('playing', false);
            playerAction = { action: 'pause', playing: false };
            break;
          case 'resume':
            setState('playing', true);
            playerAction = { action: 'resume', playing: true };
            break;
          case 'show_queue':
            playerAction = { action: 'show_queue', queue: getQueue() };
            break;
          case 'play':
            if (parsed.target) {
              try {
                const results = await searchMusic(parsed.target);
                if (results.length > 0) {
                  const track = results[0];
                  const detail = await getSongUrl(track.id);
                  const fullTrack = { ...track, url: detail.url, duration: detail.duration };
                  if (fullTrack.url) {
                    addTrack(fullTrack);
                    queuedTracks.push(fullTrack);
                    broadcast({ type: 'queue_update', track: fullTrack });
                    // Auto-play the newly added track
                    const q = getQueue();
                    playerAction = { action: 'play', track: fullTrack, currentIndex: q.queue.length - 1 };
                    setCurrentIndex(q.queue.length - 1);
                  }
                }
              } catch (e) {
                console.error('Play action search error:', e.message);
              }
            }
            break;
        }
        if (playerAction) {
          broadcast({ type: 'player_update', ...playerAction });
        }
      }

      if (parsed.play && parsed.play.length) {
        for (const query of parsed.play) {
          try {
            const results = await searchMusic(query);
            if (results.length > 0) {
              const track = results[0];
              const detail = await getSongUrl(track.id);
              const fullTrack = { ...track, url: detail.url, duration: detail.duration };
              if (fullTrack.url) {
                addTrack(fullTrack);
                queuedTracks.push(fullTrack);
                broadcast({ type: 'queue_update', track: fullTrack });
              }
            }
          } catch (e) {
            console.error('Queue track error:', e.message);
          }
        }
      }

      // Send final event with parsed result + queue info
      let audioUrl = null;
      if (parsed.say) {
        try {
          audioUrl = await synthesizeSpeech(parsed.say);
        } catch (e) {
          console.error('TTS error:', e.message);
        }
      }

      res.write(`data: ${JSON.stringify({
        type: 'done',
        parsed,
        audioUrl,
        queuedTracks: queuedTracks.map(t => ({ id: t.id, name: t.name, artist: t.artist, album: t.album, albumPic: t.albumPic, url: t.url, duration: t.duration })),
        playerAction,
      })}\n\n`);
      res.end();
    })();
  });

  stream.on('error', (err) => {
    res.write(`data: ${JSON.stringify({ type: 'error', message: err })}\n\n`);
    res.end();
  });

  // Cleanup on client disconnect
  req.on('close', () => {
    stream.removeAllListeners();
  });
});

// ── Music proxy (for HTTP-only audio sources like QQ Music) ──
app.get('/api/proxy/audio', async (req, res) => {
  const { url } = req.query;
  if (!url) return res.status(400).json({ error: 'missing url' });
  try {
    const resp = await axios.get(url, { responseType: 'stream', timeout: 30000 });
    res.set({
      'Content-Type': resp.headers['content-type'] || 'audio/mpeg',
      'Content-Length': resp.headers['content-length'],
      'Accept-Ranges': 'bytes',
      'Cache-Control': 'public, max-age=86400',
    });
    resp.data.pipe(res);
  } catch (e) {
    res.status(502).json({ error: 'proxy failed: ' + e.message });
  }
});

// ── Persona API ──────────────────────────────────────
app.get('/api/personas', (req, res) => {
  res.json({ personas: getActivePersonas() });
});

app.get('/api/personas/:name', (req, res) => {
  const persona = loadPersona(req.params.name);
  if (!persona) return res.status(404).json({ error: 'persona not found' });
  res.json({ persona });
});

app.post('/api/personas/:name', async (req, res) => {
  const { name } = req.params;
  const { content, format } = req.body;
  if (!content) return res.status(400).json({ error: 'missing content' });

  const dir = path.join(__dirname, '..', 'user_data', 'personas');
  fs.mkdirSync(dir, { recursive: true });

  const ext = format === 'json' ? '.json' : '.md';
  fs.writeFileSync(path.join(dir, `${name}${ext}`), content, 'utf8');
  res.json({ ok: true, persona: name });
});

app.delete('/api/personas/:name', (req, res) => {
  const dir = path.join(__dirname, '..', 'user_data', 'personas');
  const mdPath = path.join(dir, `${req.params.name}.md`);
  const jsonPath = path.join(dir, `${req.params.name}.json`);
  if (fs.existsSync(mdPath)) fs.unlinkSync(mdPath);
  if (fs.existsSync(jsonPath)) fs.unlinkSync(jsonPath);
  res.json({ ok: true });
});

// ── TTS endpoint (for broadcast button) ──────────────────
app.post('/api/tts', async (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ error: 'missing text' });
  try {
    const url = await synthesizeSpeech(text);
    // Notify frontend to duck music volume
    broadcast({ type: 'tts_start' });
    res.json({ url });
  } catch (e) {
    console.error('TTS error:', e.message);
    res.status(500).json({ error: e.message });
  }
});

// ── Init ─────────────────────────────────────────────────────

async function main() {
  initDb();
  initScheduler(broadcast);

  const PORT = process.env.PORT || 3000;
  server.listen(PORT, () => {
    console.log(`Claudio Radio running at http://localhost:${PORT}`);
  });
}

main().catch(console.error);

'use strict';
const axios = require('axios');

async function getSongUrl(mid) {
  const guid = String(Math.floor(Math.random() * 9e9 + 1e9));

  // Try getVkey
  const resp = await axios.get('https://u.y.qq.com/cgi-bin/musicu.fcg', {
    params: {
      format: 'json',
      inCharset: 'utf-8',
      outCharset: 'utf-8',
      data: JSON.stringify({
        req: {
          module: 'music.vkey.GetVkey',
          method: 'QueryVkey',
          param: {
            guid,
            songmid: [mid],
            songtype: [0],
          }
        }
      }),
    },
    headers: {
      Referer: 'https://y.qq.com/',
      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    },
    timeout: 10000,
  });

  const data = resp.data?.req?.data;
  if (!data) throw new Error('vkey response invalid: ' + JSON.stringify(resp.data).slice(0, 100));

  const sip = data.sip || [];
  const purlinfo = data.sipurlinfo || data.midurlinfo || [];
  const entry = purlinfo[0];

  if (!entry?.purl) {
    throw new Error('purl not found. sip=' + JSON.stringify(sip) + ' purlinfo=' + JSON.stringify(entry));
  }

  const base = sip[0] || 'https://ws.audio.xiami.com/';
  return { url: base + entry.purl, duration: entry.interval || 0 };
}

module.exports = { getSongUrl };

// Test
if (require.main === module) {
  getSongUrl('0039MnYb0qxYhV').then(r => {
    console.log('URL OK:', r.url ? 'YES len=' + r.url.length : 'NO');
    console.log('URL:', r.url);
  }).catch(e => console.error('Error:', e.message));
}

'use strict';

const axios = require('axios');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const TTS_DIR = path.join(__dirname, 'tts_cache');
if (!fs.existsSync(TTS_DIR)) fs.mkdirSync(TTS_DIR, { recursive: true });

const BASE_URL = 'https://token-plan-cn.xiaomimimo.com/v1';

async function synthesizeSpeech(text, {
  model = process.env.MIMO_TTS_MODEL || 'mimo-v2.5-tts',
  voice = process.env.MIMO_TTS_VOICE || 'base_zh_meetto',
  voice_style = '',
} = {}) {
  const apiKey = process.env.MIMO_API_KEY;
  if (!apiKey) throw new Error('MIMO_API_KEY not set in .env');

  // Check cache
  const cacheKey = text + voice + model + voice_style;
  const hash = crypto.createHash('md5').update(cacheKey).digest('hex');
  const cacheFile = path.join(TTS_DIR, `${hash}.mp3`);
  if (fs.existsSync(cacheFile)) {
    return `/tts_cache/${hash}.mp3`;
  }

  const messages = [];
  if (voice_style) {
    messages.push({ role: 'user', content: voice_style });
  }
  messages.push({ role: 'assistant', content: text });

  const resp = await axios.post(
    `${BASE_URL}/chat/completions`,
    {
      model,
      messages,
      voice_settings: { voice_id: voice },
      stream: false,
      max_completion_tokens: 4096,
    },
    {
      headers: {
        'api-key': apiKey,
        'Content-Type': 'application/json',
      },
      timeout: 30000,
    }
  );

  const audioData = resp.data?.choices?.[0]?.message?.audio?.data;
  if (!audioData) {
    throw new Error('MiMo TTS returned empty audio data');
  }

  const buffer = Buffer.from(audioData, 'base64');
  if (buffer.length < 1000) {
    throw new Error('MiMo TTS returned too small audio');
  }

  fs.writeFileSync(cacheFile, buffer);
  return `/tts_cache/${hash}.mp3`;
}

module.exports = { synthesizeSpeech };

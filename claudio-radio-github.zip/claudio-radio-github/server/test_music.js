'use strict';
const { searchMusic, getSongUrl } = require('./music');
(async () => {
  console.log('1. Testing Netease search...');
  const results = await searchMusic('周杰伦');
  console.log(`   Found ${results.length} songs`);
  console.log('   Top:', results[0]?.name, '-', results[0]?.artist);

  console.log('2. Testing play URL...');
  const url = await getSongUrl(results[0].id);
  console.log('   URL:', url.url ? 'OK (len=' + url.url.length + ')' : 'EMPTY');
  console.log('   Duration:', url.duration, 's');
})().catch(e => console.error('Error:', e.message));

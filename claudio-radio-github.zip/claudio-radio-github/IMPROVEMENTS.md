# Claudio Radio 改进计划

## 目标
让 AI DJ 能真正控制播放器（切歌、放歌），解决推荐歌曲不播放的问题。

---

## 后端改动

### 1. state.js - 队列与播放状态同步
**问题：** `addTrack` 只追加到 `state.tracks`，不更新队列；前端刷新后用 `recentTracks` 恢复，不完整。

**改动：**
- `getState()` 返回完整队列信息（不只是 recentTracks）
- 新增 `setQueue(queue)` 函数 - 替换整个队列
- `addTrack`/`removeTrack` 同时维护 `state.tracks` 和 `state.queue`
- `state.json` 增加 `currentIndex` 字段记录当前播放位置

### 2. 播放控制 API
新增路由：
```
POST /api/player/play/:index    # 播放指定曲目
POST /api/player/next           # 下一首
POST /api/player/prev           # 上一首
POST /api/player/pause          # 暂停
POST /api/player/resume         # 继续
```

### 3. buildPrompt - 注入完整上下文
修改 system prompt，追加：
```
## 当前队列
（共 N 首，当前第 X 首）
1. 歌曲A - 歌手
2. 歌曲B - 歌手（当前播放）

## 播放状态
状态: playing/paused/stopped
```

让 AI 知道：
- 队列里有什么
- 现在在放哪首
- 是"切歌"（替换当前）还是"添加"

### 4. 扩展 AI 指令识别
system prompt 增加：
```
## 指令识别
- "放 xxx"、"点 xxx" → 操作：play
- "切歌"、"下一首"、"换一首" → 操作：next
- "上一首"、"回退" → 操作：prev
- "暂停" → 操作：pause
- "继续播放" → 操作：resume

当识别到指令操作时，JSON 格式：
{
  "action": "next|prev|pause|resume|play",
  "target": "歌曲搜索关键词（仅 play 时需要）",
  "say": "播报文字"
}
```

### 5. chat/stream 路由 - 执行播放操作
当 `parsed.action` 存在时：
- `next` → 调用 `playNext()`
- `prev` → 调用 `playPrev()`
- `play` → 搜索 + 获取 URL + 添加到队列 + 播放
- 通过 WebSocket `broadcast({ type: 'player_update', ... })` 通知前端

---

## 前端改动

### 6. WebSocket 队列同步
```javascript
// 监听队列变化
socket.onmessage = (e) => {
  const d = JSON.parse(e.data);
  if (d.type === 'queue_update') { /* 更新队列 */ }
  if (d.type === 'queue_remove') { /* 移除歌曲 */ }
  if (d.type === 'queue_clear')  { /* 清空队列 */ }
  if (d.type === 'player_update') { /* 更新播放状态 */ }
};
```

### 7. init - 恢复完整队列
```javascript
// 原来只恢复 recentTracks，改为恢复完整队列
const r = await fetch('/api/state'), d = await r.json();
if (d.queue) { state.queue = d.queue; }
if (d.currentIndex >= 0) { /* 恢复播放位置 */ }
updateQueueUI();
```

### 8. AI 添加歌曲后自动播放
```javascript
// 当前端收到 done 事件且有 queuedTracks 时
if ((state.currentIndex < 0 || !state.playing) && state.queue.length) {
  playAt(state.queue.length - 1);  // 播放刚添加的这首
}
```

### 9. 播放器控制 UI（可选）
侧边栏或底部加播放控制：⏮ ⏯ ⏭ 按钮

---

## 文件清单
```
server/
  state.js        # 队列状态管理
  index.js         # API 路由 + 播放控制
  context.js       # buildPrompt（system prompt）
public/
  index.html       # 前端 WebSocket + 自动播放
```

---

## 状态
已完成 ✅

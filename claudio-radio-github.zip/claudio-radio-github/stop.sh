#!/bin/bash

SCRIPT_DIR="/home/kai/桌面/claudio-radio"
PID_FILE="/tmp/claudio-radio.pids"

echo "🛑 停止 Claudio·Kai 服务..."

if [ -f "$PID_FILE" ]; then
    read -r NETEASE_PID QQ_PID SERVER_PID < "$PID_FILE"
    [ -n "$NETEASE_PID" ] && kill $NETEASE_PID 2>/dev/null && echo "   ✅ netease-api 已停止"
    [ -n "$QQ_PID" ] && kill $QQ_PID 2>/dev/null && echo "   ✅ qq-music-api 已停止"
    [ -n "$SERVER_PID" ] && kill $SERVER_PID 2>/dev/null && echo "   ✅ server 已停止"
    rm -f "$PID_FILE"
else
    pkill -f "node.*netease-api" 2>/dev/null && echo "   ✅ netease-api 已停止"
    pkill -f "tsx.*app.ts" 2>/dev/null && echo "   ✅ qq-music-api 已停止"
    pkill -f "node.*server.*index" 2>/dev/null && echo "   ✅ server 已停止"
fi

echo "✅ 所有服务已停止"

# Claudio·Kai — 开发日志

## 2026-04-28 — 流式修复 + 心理咨询师风格 + 个性化问候语

### 流式输出修复（Phase 0 ✅）
- **根因**：Express 4.x 的 `res` 对象会 buffer 数据不推送，`res.write()` 不是直接写到 TCP
- **修复**：`res.writeHead` 后立即设置 `res.flush = () => {}`，强制 Node.js 底层 flush 每帧
- **验证**：curl 测试确认分帧到达（3160ms / 3677ms / 6990ms）

### 对话风格改造（Phase 1 — 心理咨询师模式）
- `context.js` 的 `buildPrompt()` 全面重写，删除「播音员播报」语气
- 改为：陪伴者 / 先听后说 / 用问题回应问题 / 找「被戳到」的时刻
- 保留 `personaBlock` 人格注入，叠加在心理咨询师风格之上
- 核心原则：**AI 是镜子，不是裁判**

### 个性化问候语
- 新增 `GET /api/greeting` 端点
- 根据**时间段**（早上/中午/下午/晚上/夜深）生成不同问候
- 根据**对话轮次**判断熟悉程度（第一次来/又来了/老朋友/你还在）
- 根据**最近播放**加入音乐上下文（「刚才听了李健的《贝加尔湖畔》」）
- 三条模板随机选一条输出
- 前端页面刷新/清空历史后重新拉取

### 前端 toolbar 修复
- `streamToolbarAdded` 标志位确保 `updateStreamContent` 首次更新时补上 toolbar
- 含「播报」和「停止播报」两个按钮

### 当前服务状态
- 主服务：端口 3000（`proc_5b03a302cb9c`）
- 网易云 API：端口 3001
- QQ 音乐 API：端口 3200

### 待做
- probe 按钮：AI 回复中的 `probe` 字段是否渲染为可点击追问按钮（待用户决定）
- Signal 时刻识别系统（Phase 2）
- 用户画像：先只做「音乐口味」一个维度（Phase 2）

---

## 2026-04-27 — 播放控制 + Bug 修复 + 推送仓库

### 新功能：AI 播放控制
- `state.js` 新增队列管理系统：`queue`、`currentIndex`、`playing` 状态
- 新增 8 个队列函数：`getQueue`、`setQueue`、`setCurrentIndex`、`removeFromQueue`、`clearQueue`、`playNext`、`playPrev`、`playAt`
- `index.js` 新增 5 个播放控制 API：`/api/player/next|prev|play/:index|pause|resume`
- `context.js` 的 `buildPrompt` 注入当前队列、播放状态、指令识别说明
- AI 识别语音指令："切歌"→next、"放xxx"→play、"暂停"→pause 等
- 前端 WebSocket 客户端：监听 `player_update`/`queue_update`/`queue_remove`/`queue_clear`
- 所有播放操作（按钮/AI/删除）通过 API 同步到服务器，WebSocket 广播给其他标签页

### Bug 修复
- **删除按钮失效** — `removeFromQueue` 用 `===` 比较 ID，字符串 vs 数字不匹配，改为 `String()` 统一比较
- **删除后刷新恢复** — 前端 init 从 `recentTracks`（历史）恢复队列，改为从 `state.queue` 恢复
- **删除正在播放的歌还在放** — `removeFromQueue` 返回 `wasCurrent`/`nextTrack`，前端据此自动切歌
- **切歌不同步** — 按钮同时调本地 `nextTrack()` 和 API，两边算法不一致，改为只调 API
- **dotenv 路径** — `dotenv.config()` 找不到 `server/.env`，改为显式指定 `path.join(__dirname, '.env')`
- **搜索结果不响应** — `$sr.addEventListener('click', stopPropagation)` 拦截了所有点击，已删除
- **字号不保存** — `applyFont` 写入 `localStorage`，页面加载时恢复；范围扩大到 12-40px
- **+号/双击无反应** — 改用 `addEventListener` 直接绑定在每个搜索结果元素上

### 搜索优化
- 网易云和 QQ 音乐各显示前 5 结果，其余滚动展示
- 单击无动作，双击播放，+号添加到队列
- 搜索结果区域 `max-height:360px` 支持滚动

### 推送
- 初始化 git 仓库，推送到 `git@gitee.com:kai-2299/ai-dj.git`
- 编写 README.md（功能/快速开始/环境变量/指令说明/人格系统/项目结构）
- `.gitignore` 排除 `node_modules`、`state.json`、`.env`、`tts_cache`、`user_data`

### 当前已知问题
- 搜索双击/+号在部分浏览器可能不响应（已改用 addEventListener，需 Ctrl+Shift+R 清缓存测试）
- MiniMax API 需要在 `server/.env` 配置 `MINIMAX_API_KEY`
- QQ 音乐播放 URL 是 HTTP，需通过 `/api/proxy/audio` 代理

---

## 2026-04-26 — QQ 音乐集成 + 项目保存

### 做了什么
- 集成 QQ 音乐搜索（smartbox API）+ 播放（sansenjian/qq-music-api 服务）
- QQ 音乐扫码登录，cookie 存入 `.env`
- 播放 URL 通过后端 proxy 代理解决 HTTP 跨域问题
- 前端搜索结果显示来源标签（QQ / 网易云）
- 添加 `/api/proxy/audio` 代理端点

### 当前状态
三个服务同时运行：
- netease-api :3001（网易云音乐）
- qq-music-api :3200（QQ 音乐）
- claudio-radio :3000（主服务）

### 待解决问题
- QQ 音乐部分歌曲播放失败（需要验证）
- 网易云 VIP 歌曲只有 30 秒试听
- 所有 Token/API Key 存储在 .env

### 前端设计
Apple 黑白灰风格，Apple 设计系统参数，所有交互控件已完善。

## 2026-04-26 — 前端大改版

### 改动
- 全量重写前端 HTML/CSS/JS，Apple 设计规范
- 控制图标改为简约风格（◁ ▷ ♫）
- 新增设置行：播报音量 + 播放模式 + 歌词开关
- 搜索结果可收起，点击整行直接播放
- 导入歌单功能（📂 按钮 + 文本框批量导入）
- 侧边栏字体面板（全局字号、歌词字号、行距、字重实时调整）
- DJ 名改为 Claudio·Kai

### 歌词
- 逐行滚动，当前播放行高亮（白色+加粗）
- 自动滚动到可视区域中央
- 支持显示/隐藏切换

## 2026-04-26 — 网易云切换 + AI+TTS 接入

### 做了什么
- 将音乐源从 QQ 音乐切换到 `NeteaseCloudMusicApiEnhanced/api-enhanced`
- 集成 MiniMax M2.7 作为 AI 对话（SSE 流式输出）
- 集成 MiMo TTS（音色 base_zh_wenrou / 温柔女声）
- 播报时音乐自动淡出
- 播报音量滑块独立控制

### 学习点
- MiniMax SSE 流式：`responseType: 'stream'` + EventEmitter
- MiMo TTS 新域名：`token-plan-cn.xiaomimimo.com`
- 音色列表：meetto(甜美) / taiwan(台湾腔) / wenrou(温柔) / nanxing(磁性) / xiaoyuan(校园) / chengshu(成熟) / qingxin(清新)
- 网易云 API 路由自动映射：文件名 → 路由路径

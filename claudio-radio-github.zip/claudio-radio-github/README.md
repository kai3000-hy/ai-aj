# Claudio·Kai — AI 电台

> 本地 AI 电台 DJ：AI 根据你的品味推荐音乐、自动播报，还能语音控制播放器。

## 功能

### 音乐播放
- **双源搜索** — 同时搜索网易云 + QQ 音乐，各显示前 5 结果，双击播放
- **歌词滚动** — 逐行高亮，自动跟随
- **播放模式** — 顺序 / 随机 / 单曲循环
- **队列管理** — 添加、删除、清空、导入歌单

### AI DJ
- **流式对话** — MiniMax M2.7 SSE 实时输出，打字机效果
- **心理咨询师风格** — 陪伴者定位，先听后说，用问题回应问题
- **个性化问候语** — 随时间段、熟悉程度、最近播放动态变化
- **智能选歌** — AI 根据对话推荐歌曲并自动播放
- **TTS 播报** — 温柔女声播报，音乐自动淡出
- **播放控制** — 说"切歌"、"下一首"、"暂停"、"放一首周杰伦"即可控制播放器
- **人格系统** — 支持自定义 DJ 人格

### 界面
- **Apple 设计风格** — 黑白灰，Inter 字体
- **WebSocket 实时同步** — 多标签页播放状态同步
- **字体自定义** — 侧边栏调节全局字号、歌词字号、行距、字重，自动保存

## 快速开始

```bash
# 1. 安装依赖
cd server && npm install

# 2. 配置环境变量
cp server/.env.example server/.env
# 编辑 server/.env 填入 API Key

# 3. 启动服务
./start.sh
```

浏览器打开 `http://localhost:3000`

## 外部 API 依赖

本项目依赖以下外部 API 服务：

| 服务 | 地址 | 说明 |
|------|------|------|
| 网易云音乐 API | `netease-api` 目录 / 或自建 | 端口 3001 |
| QQ 音乐 API | `qq-music-api` 目录 / 或自建 | 端口 3200 |
| MiniMax AI | 自行申请 API Key | 对话生成 |
| MiMo TTS | 自行申请 API Key | 语音播报 |

```bash
# 自建网易云音乐 API
git clone https://github.com/Binaryify/NeteaseCloudMusicApi.git
cd NeteaseCloudMusicApi && node app.js

# 自建 QQ 音乐 API
git clone https://github.com/sansenjian/qq-music-api.git
cd qq-music-api && npm install && npm run dev
```

## 端口

| 服务 | 端口 |
|------|------|
| Claudio·Kai 主服务 | 3000 |
| 网易云音乐 API | 3001 |
| QQ 音乐 API | 3200 |

## 环境变量

在 `server/.env` 中配置：

| 变量 | 说明 |
|------|------|
| `MINIMAX_API_KEY` | MiniMax AI 对话 API Key |
| `MIMO_API_KEY` | MiMo TTS API Key |
| `MIMO_TTS_MODEL` | TTS 模型 (mimo-v2.5-tts) |
| `MIMO_TTS_VOICE` | TTS 音色 (base_zh_wenrou) |
| `QQ_MUSIC_COOKIE` | QQ 音乐登录 Cookie |
| `PORT` | 主服务端口 (默认 3000) |

## AI 播放控制指令

对 AI 说以下关键词即可控制播放器：

| 指令 | 动作 |
|------|------|
| "放 xxx"、"来一首 xxx" | 搜索并播放 |
| "切歌"、"下一首" | 播放下一首 |
| "上一首" | 播放上一首 |
| "暂停"、"停下来" | 暂停播放 |
| "继续播放"、"接着放" | 恢复播放 |
| "播放列表"、"队列" | 查看当前播放队列 |

## 人格系统

将人格文件放入 `user_data/personas/` 目录：

- `.md` 格式：纯文本描述，直接嵌入 system prompt
- `.json` 格式：结构化字段（name/tone/style/rules/catchphrases）

## 技术栈

- **后端**：Node.js + Express + WebSocket
- **前端**：Vanilla JS 单页应用
- **AI**：MiniMax M2.7（对话）+ MiMo（TTS）
- **音乐**：NeteaseCloudMusicApiEnhanced + QQ Music API
- **设计**：Apple 设计系统，Inter 字体

## 项目结构

```
claudio-radio/
├── server/              # Node.js 后端
│   ├── index.js         # Express + WebSocket 主服务
│   ├── state.js         # 队列与状态管理
│   ├── context.js       # AI prompt 构建
│   ├── mimo.js          # MiniMax AI 对话
│   ├── music.js         # 网易云音乐
│   ├── qqmusic.js       # QQ 音乐
│   ├── tts.js           # TTS 语音合成
│   ├── scheduler.js     # 定时任务
│   └── .env             # 环境变量（不提交）
├── public/
│   └── index.html       # 前端单页应用
└── user_data/           # 人格文件（不提交）
```

## License

MIT
